<?php 
$mysqli = new mysqli("127.0.0.1", "root", "", "db_melati");
?>