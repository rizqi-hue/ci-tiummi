<div class="row">
	<div class="col-lg-12">
		<ol class="breadcrumb">
			<li>
				<i class="fa fa-dashboard"></i>  <a href="<?php echo base_url().'./person' ?>">Dashboard</a>
			</li>
			<li class="active">
				<i class="fa fa-home"></i> Jl. Raya Siliwangi No. 111 Cicurug Telp.0266 731002 POS 43359 Kab. Sukabumi Jabar
			</li>
		</ol>
	</div>
</div>