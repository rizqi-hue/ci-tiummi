<div class="x_content">
<h2>Jadwal Lab <?php echo $lab;?></h2>
<table id="datatable-buttons" class="table table-striped table-bordered">
					
	<thead>
		<tr>
			<th class="text-center">JAM</th>
			<th class="text-center">SENIN</th>
			<th class="text-center">SELASA</th>
			<th class="text-center">RABU</th>
			<th class="text-center">KAMIS</th>
			<th class="text-center">JUMAT</th>
		</tr>
	</thead>
	<tbody>
	<?php
		foreach($kata as $r){//waktu
			echo"<tr>";
				echo"<td align='center'>".$r->jam." </td>";
				
				$hari=2;//hari senin 
				$matakul=$this->app_model->find_jadwal_matakul($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				$dosen=$this->app_model->find_jadwal_dosen($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				echo"<td>".$this->app_model->find_matakul($matakul)."<br/>
				<b>".$this->app_model->find_dosen($dosen)."<b>
				
				</td>";
				$hari=3;//hari selasa
				$matakul=$this->app_model->find_jadwal_matakul($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				$dosen=$this->app_model->find_jadwal_dosen($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				echo"<td>".$this->app_model->find_matakul($matakul)."<br/>
				<b>".$this->app_model->find_dosen($dosen)."<b></td>";
				$hari=4;//hari rabu
				$matakul=$this->app_model->find_jadwal_matakul($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				$dosen=$this->app_model->find_jadwal_dosen($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				echo"<td>".$this->app_model->find_matakul($matakul)."<br/>
				<b>".$this->app_model->find_dosen($dosen)."<b></td>";
				$hari=5;//hari kamis
				$matakul=$this->app_model->find_jadwal_matakul($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				$dosen=$this->app_model->find_jadwal_dosen($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				echo"<td>".$this->app_model->find_matakul($matakul)."<br/>
				<b>".$this->app_model->find_dosen($dosen)."<b></td>";
				$hari=6;//hari jumat
				$matakul=$this->app_model->find_jadwal_matakul($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				$dosen=$this->app_model->find_jadwal_dosen($r->kode,$kelas,$smt,$thpel,$lab,$hari);
				echo"<td>".$this->app_model->find_matakul($matakul)."<br/>
				<b>".$this->app_model->find_dosen($dosen)."<b></td>";
			echo"</tr>";
		}
	?>
	</tbody>

</table>
</div>