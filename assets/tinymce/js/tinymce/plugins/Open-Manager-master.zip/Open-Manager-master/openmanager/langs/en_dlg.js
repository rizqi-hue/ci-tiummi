tinyMCE.addI18n('en.elvtimage_dlg',{
	title : 'Open Manager'
});
